rm -fr date*mpo_dmrg
rm log_*
rm date_*
rm tmp_sop*
rm tmp_pop*
rm *_NQt*
rm *_Qt*
rm sop
rm pop
rm top

#mpiexec -n 4 python main_spmps.py
mpiexec -n 2 python main_spmps.py
#kernprof -l -v main_spmps.py
